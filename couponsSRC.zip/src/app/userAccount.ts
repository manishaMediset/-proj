export class UserAccount {
    username: string;
    email: string;
    mobileno: number;
    password: string;
  

}