export class Cart
{
    couponname:string;
    copounCode:number;
}