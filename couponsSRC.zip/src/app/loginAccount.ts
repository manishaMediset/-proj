export class LoginAccount
{
    username:string;
   /*  localStorage.getItem('uname'); */
    password:string;
    couponCode:number;
    accountno:number;
    accPassword:string;
    imageUrl:string;
    price:number;
    
}



